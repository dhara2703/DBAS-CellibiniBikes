from django.apps import AppConfig


class MasterinventoryConfig(AppConfig):
    name = 'masterInventory'
