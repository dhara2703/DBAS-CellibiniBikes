from django.apps import AppConfig


class TaskscheduleConfig(AppConfig):
    name = 'taskschedule'
